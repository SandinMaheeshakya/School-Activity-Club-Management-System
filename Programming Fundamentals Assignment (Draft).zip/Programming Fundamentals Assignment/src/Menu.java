import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.util.Callback;
import javafx.util.Duration;

import javax.imageio.ImageIO;
import javax.xml.soap.Text;
import java.awt.*;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class Menu extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Create the tab pane and tabs
        TabPane tabPane = new TabPane();
        tabPane.setPadding(new Insets(20,30,20,30));
        Tab createTab = new Tab("Create");
        Tab viewTab = new Tab("View");
        Tab updateTab = new Tab("Update");
        Tab randomDealersTab = new Tab("Random Dealers");
        Tab allDealersTab = new Tab("All Dealers");

        // Create panels for each tab
        Pane createPanel = createCreateTabContent();
        Pane viewPanel = createViewTabContent();
        Pane updatePanel = createUpdateTabContent();
        Pane randoDdealersPanel = createRandomDealersTabContent();
        Pane allDealersPanel = createAllDealersTabContent();

        // Set the content of each tab to its respective panel
        createTab.setContent(createPanel);
        viewTab.setContent(viewPanel);
        updateTab.setContent(updatePanel);
        randomDealersTab.setContent(randoDdealersPanel);
        allDealersTab.setContent(allDealersPanel);

        // Add the tabs to the tab pane
        tabPane.getTabs().addAll(createTab, viewTab, updateTab, randomDealersTab, allDealersTab);

        // Create the scene and set it to the primary stage
        Scene scene = new Scene(tabPane, 1500, 900);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Create the content for the "Create" tab
    private Pane createCreateTabContent() {
        VBox createPanel = new VBox(10);

        Label itemCodeLabel = new Label("Item Code:");
        TextField itemCodeText = new TextField();
        itemCodeText.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                itemCodeText.setText(oldValue);
            }
        });

        Label itemNameLabel = new Label("Item Name:");
        TextField itemNameText = new TextField();

        Label itemBrandLabel = new Label("Item Brand");
        TextField itemBrandText = new TextField();

        Label itemCategorylabel = new Label("Item Category:");
        ComboBox<String> itemCategoryComboBox = new ComboBox<>();
        itemCategoryComboBox.getItems().addAll("Headset","Monitor","Keyboards", "CPU","UPS");
        itemCategoryComboBox.setValue("Headset");

        Label itemPriceLabel = new Label("Item Price:");
        TextField itemPriceText = new TextField();
        itemPriceText.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*\\.?\\d*")) {
                itemPriceText.setText(oldValue);
            }
            else if(!newValue.matches("\\d*")){
                itemPriceText.setText(oldValue);
            }
        });

        Label itemQuantityLabel = new Label("Item Quantity:");
        TextField itemQuantityText = new TextField();
        itemQuantityText.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                itemQuantityText.setText(oldValue);
            }
        });

        Label itemPurchaseDateLabel = new Label("Item Purchase Date:");
        DatePicker itemPurchaseDatePicker = new DatePicker();

        // Set the date cell factory to disable future dates
        itemPurchaseDatePicker.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                if (date.isAfter(LocalDate.now())) {
                    setDisable(true);
                }
            }
        });
        itemPurchaseDatePicker.setValue(LocalDate.now());

        Label itemImageLabel = new Label("Item Image:");
        TextField itemImageText = new TextField();
        itemImageText.setDisable(true);
        Button itemImagebrowseButton = new Button("Browse");

        ImageView imageView = new ImageView();
        imageView.setFitWidth(150);
        imageView.setFitHeight(150);


        WebView webView = new WebView();
        WebEngine webEngine = webView.getEngine();

        //browse an image on click
        itemImagebrowseButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Select Image File");
            FileChooser.ExtensionFilter imageFilter =
                    new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif");
            fileChooser.getExtensionFilters().add(imageFilter);

            File selectedFile = fileChooser.showOpenDialog(itemImagebrowseButton.getScene().getWindow());
            if (selectedFile != null) {
                itemImageText.setText(selectedFile.toURI().toString());
                String imagePath = selectedFile.toURI().toString();
                String htmlContent = "<html><body><img src=\"" + imagePath + "\" style=\"max-width: 100px; max-height: 100px;\"></body></html>";
                webEngine.loadContent(htmlContent);
            }

        });



        Button btnSave = new Button("Save");
        Button btnClear = new Button("Clear");

        //Create Item click event================================================================================
        btnSave.setOnAction(e -> {
            // Get the input from the text fields and other components
            String code = itemCodeText.getText();
            String name = itemNameText.getText();
            String brand = itemBrandText.getText();
            String category = itemCategoryComboBox.getValue().toString();
            String price = itemPriceText.getText();
            String quantity = itemQuantityText.getText();
            String purchaseDate = itemPurchaseDatePicker.getValue().toString();
            String image = itemImageText.getText();

            // Initialize a variable to store the name of the first empty field
            String firstEmptyField = null;

            // Perform validation to check if any of the required fields are empty
            if (code.isEmpty()) {
                firstEmptyField = "Item Code";
            } else if (name.isEmpty()) {
                firstEmptyField = "Item Name";
            } else if (brand.isEmpty()) {
                firstEmptyField = "Item Brand";
            } else if (category.isEmpty()) {
                firstEmptyField = "Item Category";
            } else if (price.isEmpty()) {
                firstEmptyField = "Item Price";
            } else if (quantity.isEmpty()) {
                firstEmptyField = "Item Quantity";
            } else if (purchaseDate.isEmpty()) {
                firstEmptyField = "Purchase Date";
            } else if (image.isEmpty()) {
                firstEmptyField = "Item Image";
            }


            if (firstEmptyField != null) {
                // Display a custom error alert for the first empty field
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setTitle("Error");
                errorAlert.setHeaderText(null);
                errorAlert.setContentText("Please fill in the required field: " + firstEmptyField);
                errorAlert.showAndWait();
            } else {

                //check code duplication
                itemData_controller idc = new itemData_controller() {};
                itemData idata = null;
                try {
                    idata = idc.validate_item(code);

                    String retrievedCode = (idata != null) ? idata.getCode() : null;

                    if(code.equals(retrievedCode)){
                        Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                        errorAlert.setTitle("Error");
                        errorAlert.setHeaderText(null);
                        errorAlert.setContentText("Item with code already exists. Use another code");
                        errorAlert.showAndWait();
                    }
                    else{
                        if(code.length() <= 3){
                            itemData i = new itemData(code, name, brand, category, price, quantity, purchaseDate, image);
                            idc.addItem(i);

                            // Display a success alert
                            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                            successAlert.setTitle("Save Information");
                            successAlert.setHeaderText(null);
                            successAlert.setContentText("Item saved successfully!");
                            successAlert.showAndWait();

                            // Clear fields after saving
                            itemCodeText.setText("");
                            itemNameText.setText("");
                            itemBrandText.setText("");
                            itemCategoryComboBox.setValue("Headset");
                            itemPriceText.setText("");
                            itemQuantityText.setText("");
                            itemPurchaseDatePicker.setValue(LocalDate.now());
                            itemImageText.setText("");
                            webEngine.loadContent("<html></html>");
                        }
                        else
                        {
                            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                            errorAlert.setTitle("Error");
                            errorAlert.setHeaderText(null);
                            errorAlert.setContentText("Code cannot be longer than 3 characters");
                            errorAlert.showAndWait();
                        }
                    }
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        //Create Item click event================================================================================

        //Clear function start ===================================================================================
        btnClear.setOnAction(e -> {
                    //clear fields
                    itemCodeText.setText("");
                    itemNameText.setText("");
                    itemBrandText.setText("");
                    itemCategoryComboBox.setValue("Headset");
                    itemPriceText.setText("");
                    itemQuantityText.setText("");
                    itemPurchaseDatePicker.setValue(LocalDate.now());
                    itemImageText.setText("");
                    webEngine.loadContent("<html></html>");
        });
        //private void clearFields(){

        //}
        //Clear function end   ===================================================================================

        // Add tools to the panel
        createPanel.getChildren().addAll(itemCodeLabel,itemCodeText, itemNameLabel,itemNameText,itemBrandLabel,
                itemBrandText,itemCategorylabel,itemCategoryComboBox,itemPriceLabel,itemPriceText, itemQuantityLabel,
                itemQuantityText,itemPurchaseDateLabel, itemPurchaseDatePicker,itemImageLabel, itemImageText,itemImagebrowseButton,webView,btnClear, btnSave );

        return createPanel;
    }
    // Create the content for the "View" tab
    private Pane createViewTabContent() {
        VBox viewPanel = new VBox(10);

        WebView webView = new WebView();
        WebEngine webEngine = webView.getEngine();

        Label view_ItemCodeLabel = new Label("Click on item to delete:");
        TextField view_ItemCodeText = new TextField();
        view_ItemCodeText.setDisable(true);

        Label view_SearchItemCodeLabel = new Label("Search Item:");
        TextField view_SearchItemCodeText = new TextField();
        Button view_BtnSearch = new Button("Search");

        Button view_BtnDelete = new Button("Delete");
        Button view_BtnLoad = new Button("Load");

        TextField view_textbox_update = new TextField();
        view_textbox_update.setText("TO UPDATE ITEM, SELECT ITEM AND GO TO UPDATE PANEL");
        view_textbox_update.setDisable(true);

        //Data Table Start======================================================================================
        TableView<itemData> itemTable = new TableView<>();
        itemTable.setEditable(false);
        itemTable.setFixedCellSize(50); // Set the fixed height of the rows in the TableView

        // Create columns for the TableView
        TableColumn<itemData, String> codeColumn = new TableColumn<>("Code");
        codeColumn.setCellValueFactory(new PropertyValueFactory<>("code"));
        codeColumn.setPrefWidth(50);

        TableColumn<itemData, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameColumn.setPrefWidth(100);

        TableColumn<itemData, String> brandColumn = new TableColumn<>("Brand");
        brandColumn.setCellValueFactory(new PropertyValueFactory<>("brand"));
        brandColumn.setPrefWidth(100);

        TableColumn<itemData, String> categoryColumn = new TableColumn<>("Category");
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
        categoryColumn.setPrefWidth(100);

        TableColumn<itemData, String> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        priceColumn.setPrefWidth(100);

        TableColumn<itemData, String> quantityColumn = new TableColumn<>("Quantity");
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        quantityColumn.setPrefWidth(100);

        TableColumn<itemData, String> purchaseDateColumn = new TableColumn<>("Purchase Date");
        purchaseDateColumn.setCellValueFactory(new PropertyValueFactory<>("purchaseDate"));
        purchaseDateColumn.setPrefWidth(150);

        TableColumn<itemData, String> imageColumn = new TableColumn<>("Image Path");
        imageColumn.setCellValueFactory(new PropertyValueFactory<>("thumbnailImage"));
        imageColumn.setPrefWidth(150);

        TableColumn<itemData, String> imageDisplayColumn = new TableColumn<>("Image View");
        imageDisplayColumn.setCellValueFactory(new PropertyValueFactory<>("thumbnailImage"));
        imageDisplayColumn.setPrefWidth(200);

        imageDisplayColumn.setCellFactory(new Callback<TableColumn<itemData, String>, TableCell<itemData, String>>() {
                                       @Override
                                       public TableCell<itemData, String> call(TableColumn<itemData, String> column) {
                                           return new TableCell<itemData, String>() {
                                               private final WebView webView = new WebView();

                                               {
                                                   setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                                                   setGraphic(webView);
                                               }

                                               @Override
                                               protected void updateItem(String thumbnailImage, boolean empty) {
                                                   super.updateItem(thumbnailImage, empty);
                                                   if (empty || thumbnailImage == null) {
                                                       // Set an empty WebView if the cell is empty or the thumbnailImage is null
                                                       webView.getEngine().loadContent("");
                                                   } else {
                                                       // Set the WebView content to display the HTML image
                                                       String htmlContent = "<html><body><img src=\"" + thumbnailImage + "\" style=\"max-width: 100px; max-height: 100px;\"></body></html>";
                                                       webView.getEngine().loadContent(htmlContent);
                                                   }
                                               }
                                           };
                                       }
                                   });

        // Add columns to the TableView
        itemTable.getColumns().addAll(codeColumn, nameColumn, brandColumn, categoryColumn, priceColumn, quantityColumn, purchaseDateColumn, imageColumn,imageDisplayColumn);
        itemTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        itemData_controller idcLst = new itemData_controller();
        itemTable.setItems(idcLst.readItem());

        //Data Table End======================================================================================
        // Add tools to the panel
        viewPanel.getChildren().addAll(view_ItemCodeLabel, view_ItemCodeText, view_BtnDelete, view_BtnLoad, view_SearchItemCodeLabel, view_SearchItemCodeText, view_BtnSearch, itemTable,
                view_textbox_update);

        //Load table data on click ===========================================================================
        view_BtnLoad.setOnAction(e -> {
            itemTable.setItems(idcLst.readItem());
        });

        //Delete a item on click ===========================================================================
        view_BtnDelete.setOnAction(e -> {

            String code = view_ItemCodeText.getText();
            ArrayList<String> tempArray = new ArrayList<>();

            try{
                try(FileReader fr = new FileReader("items.txt")){

                    Scanner reader = new Scanner(fr);
                    String line;
                    String[] lineArr;

                    while((line=reader.nextLine()) != null){

                        lineArr = line.split("    ");
                        if(lineArr[0].equals(code)){
                            tempArray.remove(
                                    lineArr[0]);

                        }else{
                            tempArray.add(line);
                        }
                    }
                    fr.close();
                }catch (Exception ex){

                }

            }catch (Exception ex){

            }

            try{
                try(PrintWriter pr = new PrintWriter("items.txt")){

                    for (String str : tempArray)
                    {
                        pr.println(str);
                    }
                    pr.close();
                }catch (Exception ex){

                }

            }catch (Exception ex){

            }

            itemTable.setItems(idcLst.readItem());

            view_ItemCodeText.setText("");
        });
        //Delete a item on click end===========================================================================


        //Delete a item on click ===========================================================================
        view_BtnSearch.setOnAction(e -> {
            String code = view_SearchItemCodeText.getText();
            itemData_controller dILst = new itemData_controller();
            itemTable.setItems(dILst.searchItem(code));

            // Check if the list is empty and show an alert if it is
            if (itemTable.getItems().isEmpty()) {
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setTitle("Error");
                errorAlert.setHeaderText(null);
                errorAlert.setContentText("The item with the given code does not exist.");
                errorAlert.showAndWait();
            }
        });
        //Delete a item on click end===========================================================================

        //Click table row function
        // Assuming tableView is the TableView in your "View" tab
        itemTable.setOnMouseClicked(e -> {
            if (e.getClickCount() == 1) { // Detect single-click on a row
                // Get the selected item (row) from the TableView
                itemData selectedItem = itemTable.getSelectionModel().getSelectedItem();

                // Populate the text fields with the data from the selected row
                if (selectedItem != null) {
                    view_ItemCodeText.setText(selectedItem.getCode());

                    //assign to global variables
                    u_code = selectedItem.getCode();
                    u_name = selectedItem.getName();
                    u_brand = selectedItem.getBrand();
                    u_category = selectedItem.getCategory();
                    u_price = selectedItem.getPrice();
                    u_quantity = selectedItem.getQuantity();
                    u_purchaseDate = selectedItem.getPurchaseDate();
                    u_image = selectedItem.getThumbnailImage();

                    isUpdate = true;
                }
            }
        });

        return viewPanel;
    }
    private Pane createUpdateTabContent() {
        VBox createPanel = new VBox(10);

        Button btnUpdateSelectedItem = new Button("Update the selected item");
        Label itemCodeLabel = new Label("Item Code:");
        TextField itemCodeText = new TextField();
        itemCodeText.setDisable(true);
        itemCodeText.setText("TO UPDATE AN ITEM, SELECT ITEM IN VIEW PANEL");

        Label itemNameLabel = new Label("Item Name:");
        TextField itemNameText = new TextField();

        Label itemBrandLabel = new Label("Item Brand");
        TextField itemBrandText = new TextField();

        Label itemCategorylabel = new Label("Item Category:");
        ComboBox<String> itemCategoryComboBox = new ComboBox<>();
        itemCategoryComboBox.getItems().addAll("Headset","Monitor","Keyboards", "CPU","UPS");
        itemCategoryComboBox.setValue("Headset");

        Label itemPriceLabel = new Label("Item Price:");
        TextField itemPriceText = new TextField();
        itemPriceText.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*\\.?\\d*")) {
                itemPriceText.setText(oldValue);
            }
            else if(!newValue.matches("\\d*")){
                itemPriceText.setText(oldValue);
            }
        });

        Label itemQuantityLabel = new Label("Item Quantity:");
        TextField itemQuantityText = new TextField();
        itemQuantityText.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                itemQuantityText.setText(oldValue);
            }
        });

        Label itemPurchaseDateLabel = new Label("Item Purchase Date:");
        DatePicker itemPurchaseDatePicker = new DatePicker();

        // Set the date cell factory to disable future dates
        itemPurchaseDatePicker.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                if (date.isAfter(LocalDate.now())) {
                    setDisable(true);
                }
            }
        });

        Label itemImageLabel = new Label("Item Image:");
        TextField itemImageText = new TextField();

        Button btnSave = new Button("Save");
        btnSave.setDisable(true);
        Button btnClear = new Button("Clear");

        itemImageText.setDisable(true);
        Button itemImagebrowseButton = new Button("Browse");

        ImageView imageView = new ImageView();
        imageView.setFitWidth(150);
        imageView.setFitHeight(150);


        WebView webView = new WebView();
        WebEngine webEngine = webView.getEngine();

        //browse an image on click
        itemImagebrowseButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Select Image File");
            FileChooser.ExtensionFilter imageFilter =
                    new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif");
            fileChooser.getExtensionFilters().add(imageFilter);

            File selectedFile = fileChooser.showOpenDialog(itemImagebrowseButton.getScene().getWindow());
            if (selectedFile != null) {
                itemImageText.setText(selectedFile.toURI().toString());
                String imagePath = selectedFile.toURI().toString();
                String htmlContent = "<html><body><img src=\"" + imagePath + "\" style=\"max-width: 100px; max-height: 100px;\"></body></html>";
                webEngine.loadContent(htmlContent);
            }

        });

        btnUpdateSelectedItem.setOnAction(e -> {
            if(isUpdate){
                itemCodeLabel.setText("Item Code: "+u_code);
                itemNameText.setText(u_name);
                itemBrandText.setText(u_brand);
                itemCategoryComboBox.setValue(u_category);
                itemPriceText.setText(u_price);
                itemQuantityText.setText(u_quantity);
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                LocalDate purchaseDate = LocalDate.parse(u_purchaseDate, formatter);
                itemPurchaseDatePicker.setValue(purchaseDate);
                itemImageText.setText(u_image);

                String imagePath = u_image;
                String htmlContent = "<html><body><img src=\"" + imagePath + "\" style=\"max-width: 100px; max-height: 100px;\"></body></html>";
                webEngine.loadContent(htmlContent);

                btnSave.setDisable(false);
                itemImageText.setDisable(true);
            }
            else
            {
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setTitle("Error");
                errorAlert.setHeaderText(null);
                errorAlert.setContentText("Please select an item first");
                errorAlert.showAndWait();
            }
        });

        //Create Item click event================================================================================
        btnSave.setOnAction(e -> {
            String code = itemCodeText.getText();
            String name = itemNameText.getText();
            String brand = itemBrandText.getText();
            String category = itemCategoryComboBox.getValue().toString();
            String price = itemPriceText.getText();
            String quantity = itemQuantityText.getText();
            String purchaseDate = itemPurchaseDatePicker.getValue().toString();
            String image = itemImageText.getText();

            itemData i = new itemData(code, name, brand, category, price, quantity, purchaseDate, image);

            // Initialize a variable to store the name of the first empty field
            String firstEmptyField = null;

            if (code.isEmpty()) {
                firstEmptyField = "Item Code";
            } else if (name.isEmpty()) {
                firstEmptyField = "Item Name";
            } else if (brand.isEmpty()) {
                firstEmptyField = "Item Brand";
            } else if (category.isEmpty()) {
                firstEmptyField = "Item Category";
            } else if (price.isEmpty()) {
                firstEmptyField = "Item Price";
            } else if (quantity.isEmpty()) {
                firstEmptyField = "Item Quantity";
            } else if (purchaseDate.isEmpty()) {
                firstEmptyField = "Purchase Date";
            } else if (image.isEmpty()) {
                firstEmptyField = "Item Image";
            }


            if (firstEmptyField != null) {
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setTitle("Error");
                errorAlert.setHeaderText(null);
                errorAlert.setContentText("Please fill in the required field: " + firstEmptyField);
                errorAlert.showAndWait();
            } else {
                //update function
                ArrayList<String> tempArray = new ArrayList<>();

                try{
                    try(FileReader fr = new FileReader("items.txt")){

                        Scanner reader = new Scanner(fr);
                        String line;
                        String[] lineArr;

                        while((line=reader.nextLine()) != null){

                            lineArr = line.split("       ");
                            if(lineArr[0].equals(i.getCode())){
                                tempArray.add(
                                        lineArr[0] +"       "+ i.getName()+"       "+i.getBrand()+"       "+i.getCategory()+
                                                "       "+i.getPrice()+"       "+i.getQuantity()+"       "+ i.getPurchaseDate()+"       "+ i.getThumbnailImage());

                            }else{
                                tempArray.add(line);
                            }
                        }
                        fr.close();
                    }catch (Exception ex){

                    }

                }catch (Exception ex3){

                }
                try{
                    try(PrintWriter pr = new PrintWriter("items.txt")){

                        for (String str : tempArray)
                        {
                            pr.println(str);
                        }
                        pr.close();
                    }catch (Exception ex3){

                    }

                }catch (Exception ex){

                }

                ////Display Alert
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Save Information");
                alert.setHeaderText(null);
                alert.setContentText("Item updated successfully!");
                alert.showAndWait();

                //clear fields
                itemCodeLabel.setText("Item Code: ");
                itemNameText.setText("");
                itemBrandText.setText("");
                itemCategoryComboBox.setValue("Headset");
                itemPriceText.setText("");
                itemQuantityText.setText("");
                itemPurchaseDatePicker.setValue(LocalDate.now());
                itemImageText.setText("");
                webEngine.loadContent("<html></html>");

                btnSave.setDisable(true);
                isUpdate = false;
            }
        });
        //Create Item click event================================================================================

        //Clear function start ===================================================================================
        btnClear.setOnAction(e -> {
            //clear fields
            itemCodeLabel.setText("Item Code: ");
            itemNameText.setText("");
            itemBrandText.setText("");
            itemCategoryComboBox.setValue("Headset");
            itemPriceText.setText("");
            itemQuantityText.setText("");
            itemPurchaseDatePicker.setValue(LocalDate.now());
            itemImageText.setText("");
            webEngine.loadContent("<html></html>");

            btnSave.setDisable(true);
            isUpdate = false;
        });
        //private void clearFields(){

        //}
        //Clear function end   ===================================================================================

        // Add tools to the panel
        createPanel.getChildren().addAll(btnUpdateSelectedItem,itemCodeLabel,itemCodeText, itemNameLabel,itemNameText,itemBrandLabel,
                itemBrandText,itemCategorylabel,itemCategoryComboBox,itemPriceLabel,itemPriceText, itemQuantityLabel,
                itemQuantityText,itemPurchaseDateLabel, itemPurchaseDatePicker,itemImageLabel, itemImageText,itemImagebrowseButton,webView,btnClear, btnSave );

        return createPanel;
    }
    private Pane createRandomDealersTabContent(){
        VBox viewPanel = new VBox(10);

        Button btnGenerateRandomDealers = new Button("Generate Dealers");
        //Data Table Start======================================================================================
        Label dealerTableHeader = new Label("Dealer Table:");
        TableView<dealerData> dealerTable = new TableView<>();
        dealerTable.setEditable(false);
        dealerTable.setFixedCellSize(50); // Set the fixed height of the rows in the TableView

        // Create columns for the TableView
        TableColumn<dealerData, String> idColumn = new TableColumn<>("Dealer ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        idColumn.setPrefWidth(200);
        idColumn.setStyle("-fx-alignment: CENTER;");

        TableColumn<dealerData, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameColumn.setPrefWidth(200);

        TableColumn<dealerData, String> numberColumn = new TableColumn<>("Telephone");
        numberColumn.setCellValueFactory(new PropertyValueFactory<>("number"));
        numberColumn.setPrefWidth(200);

        TableColumn<dealerData, String> cityColumn = new TableColumn<>("City");
        cityColumn.setCellValueFactory(new PropertyValueFactory<>("city"));
        cityColumn.setPrefWidth(200);

        // Add columns to the TableView
        dealerTable.getColumns().addAll(idColumn, nameColumn, numberColumn, cityColumn);
        dealerTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        //Data Table End======================================================================================

        //Data Table Start======================================================================================
        Label dealerItemTableHeader = new Label("Dealer Items Table:");
        TableView<dealerItemData> dealerItemTable = new TableView<>();
        dealerItemTable.setEditable(false);
        dealerItemTable.setFixedCellSize(50); // Set the fixed height of the rows in the TableView

        // Create columns for the TableView
        TableColumn<dealerItemData, String> itemNameColumn = new TableColumn<>("Name");
        itemNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        itemNameColumn.setPrefWidth(200);

        TableColumn<dealerItemData, String> brandColumn = new TableColumn<>("Brand");
        brandColumn.setCellValueFactory(new PropertyValueFactory<>("brand"));
        brandColumn.setPrefWidth(200);

        TableColumn<dealerItemData, String> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        priceColumn.setPrefWidth(200);

        TableColumn<dealerItemData, String> quantityColumn = new TableColumn<>("Quantity");
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        quantityColumn.setPrefWidth(200);

        // Add columns to the TableView
        dealerItemTable.getColumns().addAll(itemNameColumn,brandColumn,priceColumn,quantityColumn);
        dealerItemTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        //Data Table End======================================================================================

        // Add tools to the panel
        viewPanel.getChildren().addAll(btnGenerateRandomDealers,dealerTableHeader,dealerTable,dealerItemTableHeader,dealerItemTable);

        //Click table row function
        dealerTable.setOnMouseClicked(e -> {
            if (e.getClickCount() == 1) {
                dealerData selectedItem = dealerTable.getSelectionModel().getSelectedItem();

                if (selectedItem != null) {

                    dealer_id = selectedItem.getId();
                    dealerItemData_controller dILst = new dealerItemData_controller();
                    dealerItemTable.setItems(dILst.readDealerItem(dealer_id));
                }
            }
        });

        btnGenerateRandomDealers.setOnAction(e -> {
            dealerData_controller dLst = new dealerData_controller();
            dealerTable.setItems(dLst.readRandomDealers());
        });

        return viewPanel;
    }
    private Pane createAllDealersTabContent(){
        VBox viewPanel = new VBox(10);

        //Data Table Start======================================================================================
        Label dealerTableHeader = new Label("Dealer Table:");
        TableView<dealerData> dealerTable = new TableView<>();
        dealerTable.setEditable(false);
        dealerTable.setFixedCellSize(50); // Set the fixed height of the rows in the TableView

        // Create columns for the TableView
        TableColumn<dealerData, String> idColumn = new TableColumn<>("Dealer ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        idColumn.setPrefWidth(200);
        idColumn.setStyle("-fx-alignment: CENTER;");

        TableColumn<dealerData, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameColumn.setPrefWidth(200);

        TableColumn<dealerData, String> numberColumn = new TableColumn<>("Telephone");
        numberColumn.setCellValueFactory(new PropertyValueFactory<>("number"));
        numberColumn.setPrefWidth(200);

        TableColumn<dealerData, String> cityColumn = new TableColumn<>("City");
        cityColumn.setCellValueFactory(new PropertyValueFactory<>("city"));
        cityColumn.setPrefWidth(200);

        // Add columns to the TableView
        dealerTable.getColumns().addAll(idColumn, nameColumn, numberColumn, cityColumn);
        dealerTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        dealerData_controller idcLst = new dealerData_controller();
        dealerTable.setItems(idcLst.readAllDealers());
        //Data Table End======================================================================================

        // Add tools to the panel
        viewPanel.getChildren().addAll(dealerTable);

        return viewPanel;
    }
    //global variables
    String u_code = "";String u_name = "";String u_brand = "";String u_category = "";
    String u_price = ""; String u_quantity = ""; String u_purchaseDate = "";String u_image = "";
    String dealer_id = "";
    Boolean isUpdate = false;

    // Create the content for the "Update" tab
}
