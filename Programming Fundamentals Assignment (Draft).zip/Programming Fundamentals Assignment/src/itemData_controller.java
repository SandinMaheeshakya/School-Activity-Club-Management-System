import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class itemData_controller {
    private static final String storage_file = "items.txt";
    FileWriter fw = null;
    BufferedWriter bw = null;

    //Add item start =========================================================================================================
    public boolean addItem (itemData i){
        try{
            PrintWriter out = null;
            String itemData = i.getCode()+"       "+ i.getName()+"       "+i.getBrand()+"       "+i.getCategory()+
                    "       "+i.getPrice()+"       "+i.getQuantity()+"       "+ i.getPurchaseDate()+"       "+ i.getThumbnailImage();

            out = new PrintWriter(new BufferedWriter(new FileWriter(storage_file, true)));
            out.println(itemData);
            out.close();
        }
        catch (IOException ex){
            Logger.getLogger(itemData_controller.class.getName()).log(Level.SEVERE,null,ex);
        }
        return true;
    }
    //Add item end   =========================================================================================================

    //Read item start ========================================================================================================
    public ObservableList<itemData> readItem() {
        ObservableList<itemData> itemDataList = FXCollections.observableArrayList();
        try {
            File itemObject = new File("items.txt");
            Scanner scan = new Scanner(itemObject);

            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                String[] itemData = line.split("       ");

                String code = itemData[0];
                String name = itemData[1];
                String brand = itemData[2];
                String category = itemData[3];
                String price = itemData[4];
                String quantity = itemData[5];
                String purchaseDate = itemData[6];
                String thumbnailImage = itemData[7];

                itemData item = new itemData(code, name, brand, category, price, quantity, purchaseDate, thumbnailImage);
                itemDataList.add(item);
            }
            scan.close();
            return itemDataList;

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
            return itemDataList;
        }
    }
    //Read item end ========================================================================================================

    //Search Item start=======================================================================
    public ObservableList<itemData> searchItem(String item_id) {
        ObservableList<itemData> itemDataList = FXCollections.observableArrayList();
        try {
            File itemObject = new File("items.txt");
            Scanner scan = new Scanner(itemObject);

            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                String[] itemData = line.split("       ");

                String code = itemData[0];
                String name = itemData[1];
                String brand = itemData[2];
                String category = itemData[3];
                String price = itemData[4];
                String quantity = itemData[5];
                String purchaseDate = itemData[6];
                String thumbnailImage = itemData[7];

                if (code.equals(item_id)) {
                    itemData itemObj = new itemData(code, name, brand, category, price, quantity, purchaseDate, thumbnailImage);
                    itemDataList.add(itemObj);
                }
            }
            scan.close();
            return itemDataList;

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
            return itemDataList;
        }
    }
    //Search Item end

    //Update items Start ===================================================================================================
    public boolean updateItem(itemData i){
        ArrayList<String> tempArray = new ArrayList<>();

        File itemObject = new File("items.txt");
        try{
            Scanner scan = new Scanner(itemObject);
            String line;
            String[] lineArray;

            String tf = "f";
            while ((line=scan.nextLine())!= null){
                lineArray = line.split("       ");
                if(lineArray[0].equals(i.getCode())) {
                    tempArray.add(lineArray[0] +"       "+ i.getName()+"       "+i.getBrand()+"       "+i.getCategory()+
                            "       "+i.getPrice()+"       "+i.getQuantity()+"       "+ i.getPurchaseDate()+"       "+ i.getThumbnailImage());
                    return true;
                }
                else
                {
                    tempArray.add(line);
                }
            }
            scan.close();
        }catch (Exception ex) {

        }
        try{
            try(PrintWriter pr = new PrintWriter("items.txt")){

                for (String str : tempArray)
                {
                    pr.println(str);
                }
                pr.close();
            }catch (Exception ex3){

            }

        }catch (Exception ex){

        }
        return false;
    }
    //Update items end ===================================================================================================

    //validate item code==================================================================================================
    public itemData validate_item(String code) throws IOException{

        itemData i = null;

        try {

            FileInputStream fileInputStream = new FileInputStream(storage_file);

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));

            String readLine;

            while((readLine = bufferedReader.readLine()) != null){

                String[] item_details = readLine.split("       ");

                if (code.equals(item_details[0])) {
                    i = new itemData(){};

                    i.setCode(item_details[0]);
                }
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(itemData_controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        return i;
    }

    //validate item code==================================================================================================

}

