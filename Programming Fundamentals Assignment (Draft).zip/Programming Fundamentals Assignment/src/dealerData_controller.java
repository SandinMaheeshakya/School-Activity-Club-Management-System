import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class dealerData_controller {
    public ObservableList<dealerData> readRandomDealers() {
        ObservableList<dealerData> dealerDataList = FXCollections.observableArrayList();
        try {
            File dealerObject = new File("dealers.txt");
            Scanner scan = new Scanner(dealerObject);

            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                String[] dealerData = line.split("      ");

                String id = dealerData[0];
                String name = dealerData[1];
                String number = dealerData[2];
                String city = dealerData[3];

                dealerData dealerObj = new dealerData(id, name, number, city);
                dealerDataList.add(dealerObj);
            }
            scan.close();

            // Shuffle the list randomly
            List<dealerData> shuffledDealers = new ArrayList<>(dealerDataList);
            Collections.shuffle(shuffledDealers);

            // Get the first four elements (random rows)
            List<dealerData> randomDealers = shuffledDealers.subList(0, Math.min(4, shuffledDealers.size()));

            // Return an ObservableList containing the random dealers
            return FXCollections.observableArrayList(randomDealers);

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
            return dealerDataList;
        }
    }
    public ObservableList<dealerData> readAllDealers() {
        ObservableList<dealerData> dealerDataList = FXCollections.observableArrayList();
        try {
            File dealerObject = new File("dealers.txt");
            Scanner scan = new Scanner(dealerObject);

            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                String[] dealerData = line.split("      ");

                String id = dealerData[0];
                String name = dealerData[1];
                String number = dealerData[2];
                String city = dealerData[3];

                dealerData dealerObj = new dealerData(id,name,number,city);
                dealerDataList.add(dealerObj);
            }
            scan.close();
            return dealerDataList;

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
            return dealerDataList;
        }
    }
}
