import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class dealerItemData_controller {
    public ObservableList<dealerItemData> readDealerItem(String dealer_id) {
        ObservableList<dealerItemData> dealerItemDataList = FXCollections.observableArrayList();
        try {
            File dealerItemObject = new File("dealer_items.txt");
            Scanner scan = new Scanner(dealerItemObject);

            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                String[] dealerItemData = line.split(",");

                String currentDealerId = dealerItemData[0];
                String name = dealerItemData[1];
                String brand = dealerItemData[2];
                String price = dealerItemData[3];
                String quantity = dealerItemData[4];

                if (currentDealerId.equals(dealer_id)) {
                    dealerItemData dealerItemObj = new dealerItemData(name, brand, price, quantity);
                    dealerItemDataList.add(dealerItemObj);
                }
            }
            scan.close();
            return dealerItemDataList;

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
            return dealerItemDataList;
        }
    }
}
